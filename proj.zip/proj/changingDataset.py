import csv

def changeDataset(dataset):
	array = []
	for i in range(len(dataset)):
		for j in range(len(dataset[i])):
			x = dataset[i][j]
			if j == 0:
				if x == 'a':
					dataset[i][j] = 1
				elif x == 'b':
					dataset[i][j] = 2
			elif j == 3:
				if x == 'u':
					dataset[i][j] = 1
				elif x == 'y':
					dataset[i][j] = 2
				elif x == 'l':
					dataset[i][j] = 3
				elif x == 't':
					dataset[i][j] = 4
			elif j == 4:
				if x == 'g':
					dataset[i][j] = 1
				elif x == 'p':
					dataset[i][j] = 2
				elif x == 'gg':
					dataset[i][j] = 3
			elif j == 5:
				if x == 'c':
					dataset[i][j] = 1
				elif x == 'd':
					dataset[i][j] = 2
				elif x == 'cc':
					dataset[i][j] = 3
				elif x == 'i':
					dataset[i][j] = 4
				elif x == 'j':
					dataset[i][j] = 5
				elif x == 'k':
					dataset[i][j] = 6
				elif x == 'm':
					dataset[i][j] = 7
				elif x == 'r':
					dataset[i][j] = 8
				elif x == 'q':
					dataset[i][j] = 9
				elif x == 'w':
					dataset[i][j] = 10
				elif x == 'x':
					dataset[i][j] = 11
				elif x == 'e':
					dataset[i][j] = 12
				elif x == 'aa':
					dataset[i][j] = 13
				elif x == 'ff':
					dataset[i][j] = 14
			elif j == 6:
				if x == 'v':
					dataset[i][j] = 1
				elif x == 'h':
					dataset[i][j] = 2
				elif x == 'bb':
					dataset[i][j] = 3
				elif x == 'j':
					dataset[i][j] = 4
				elif x == 'n':
					dataset[i][j] = 5
				elif x == 'z':
					dataset[i][j] = 6
				elif x == 'dd':
					dataset[i][j] = 7
				elif x == 'ff':
					dataset[i][j] = 3
				elif x == 'o':
					dataset[i][j] = 4
			elif j == 8 or j == 9 or j == 11:
				if x == 't':
					dataset[i][j] = 1
				elif x == 'f':
					dataset[i][j] = 2
			elif j == 12:
				if x == 'g':
					dataset[i][j] = 1
				elif x == 'p':
					dataset[i][j] = 2
				elif x == 's':
					dataset[i][j] = 3
			elif j == 15:
				if x == '-':
					dataset[i][j] = 0
				elif x == '+':
					dataset[i][j] = 1
		array.append(dataset[i])
	return array

def rewriteDataset(initfile, rewritefile, rewritingSet = []):
	with open(initfile, 'r') as csvfile:
		lines = csv.reader(csvfile)
		dataset = list(lines)
		array = changeDataset(dataset)
		
	for sublist in array:
		del sublist[13]

	delete = 0
	for i in range(len(array)):
		for j in range(len(array[i])):
			if array[i][j] != '?':
				array[i][j] = float(array[i][j])
			elif array[i][j] == '?':
				delete = 1
		if delete == 0:
			rewritingSet.append(array[i])
		delete = 0

	with open(rewritefile, 'w') as csvfile:
		writer = csv.writer(csvfile)
		for i in range(len(rewritingSet)):
			writer.writerow(rewritingSet[i])

def main():
	rewritingSet = []
	rewriteDataset("crx.data", "crx.data.csv", rewritingSet)
	
main()