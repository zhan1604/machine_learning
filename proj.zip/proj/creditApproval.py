import csv
import random
import math
#import bot

def loadDataset(filename):
	with open(filename) as csvfile:
		rows = csv.reader(csvfile)
		dataset = list(rows)
		for i in range(len(dataset)):
			for j in range(len(dataset[i])):
				dataset[i][j] = float(dataset[i][j])
		return dataset

def splitDataset(dataset, ratio):
	trainingSetSize = int(len(dataset) * ratio)
	trainingSet = []
	testSet = list(dataset)
	while len(trainingSet) < trainingSetSize:
		i = random.randint(0, len(testSet) - 1)
		trainingSet.append(testSet.pop(i))
	return trainingSet, testSet

def separateByClass(dataset):
	separatedSet = {}
	for i in range(len(dataset)):
		currentRow = dataset[i]
		if (currentRow[-1] not in separatedSet):
			separatedSet[currentRow[-1]] = []
		separatedSet[currentRow[-1]].append(currentRow)
	return separatedSet

def arrange(dataset):
	arrangedSet = []
	for category in list(zip(*dataset)):
		mean = sum(category) / float(len(category))
		variance = 0
		for x in category:
			variance += pow(x - mean, 2) / float(len(category) - 1)
		arrangedSet.append((mean, math.sqrt(variance)))
	del arrangedSet[-1]
	return arrangedSet

def arrangeByClass(dataset):
	separatedSet = separateByClass(dataset)
	arrangedSet = {}
	for resultValue, testValues in separatedSet.items():
		arrangedSet[resultValue] = arrange(testValues)
	return arrangedSet

def individualPrediction(arrangedSet, individualSet):
	probabilitiesSet = {}
	for resultValue, categoryValues in arrangedSet.items():
		probabilitiesSet[resultValue] = 1
		for i in range(len(categoryValues)):
			mean = categoryValues[i][0]
			standardDeviation = categoryValues[i][1]
			x = individualSet[i]
			gaussianProbability = (1 / (math.sqrt(2 * math.pi) * standardDeviation)) * math.exp(-(math.pow(x - mean, 2) / (2 * math.pow(standardDeviation, 2))))
			probabilitiesSet[resultValue] *= gaussianProbability
	predictionResult = None
	predictionProbability = -1
	for resultValue, probabilityValue in probabilitiesSet.items():
		if predictionResult == None or probabilityValue > predictionProbability:
			predictionProbability = probabilityValue
			predictionResult = resultValue
	return predictionResult

def makePredictions(arrangedSet, testSet):
	predictionSet = []
	for i in range(len(testSet)):
		prediction = individualPrediction(arrangedSet, testSet[i])
		predictionSet.append(prediction)
	return predictionSet

def calculateAccuracy(testSet, predictionSet):
	isRight = 0
	for i in range(len(testSet)):
		if predictionSet[i] == testSet[i][-1]:
			isRight += 1
	accuracy = isRight / float(len(testSet)) * 100.0
	return accuracy

def main():
	filename = 'crx.data.csv'
	dataset = loadDataset(filename)

	#calculating the accuracy of this method by
	#splitting the original dataset into trainingSet and testSet
	#in ratio 2:1
	ratio = 0.67
	trainingSet, testSet = splitDataset(dataset, ratio)
	print(len(dataset), 'splitted into:', len(trainingSet), 'trainingSet and', len(testSet), 'testSet')

	#separation by result value: 0 or 1
	#calculating the mean and standard deviation of each training example
	arrangedSet = arrangeByClass(trainingSet)

	#making predictions
	predictionSet = makePredictions(arrangedSet, testSet)

	#calculating accuracy
	accuracy = calculateAccuracy(testSet, predictionSet)
	print("Accuracy is", accuracy, "%")

	information = [1.0, 50.0, 4.5, 1.0, 1.0, 9.0, 2.0, 2.5, 1.0, 1.0, 5.0, 2.0, 1.0, 600.0]
	#information = loadDataset("botInfo.data.csv")
	theResult = individualPrediction(arrangedSet, information)
	print(information)
	print(theResult)

	decision = "Denied"
	if theResult == 1:
		decision = "Approved"

	print(decision)

main()