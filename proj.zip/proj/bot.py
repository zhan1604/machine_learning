from twx.botapi import TelegramBot
import csv
import time

def main():
	token = '165914238:AAFGnnrzKZCMwMB4xvvUzmV48556_kb1FlQ'
	bot = TelegramBot(token)
	bot.update_bot_info().wait()
	print(bot.username)
	information = []
	user_id = int(95470207)

	for i in range(14):
		message = "Question number " + str(i + 1)
		result = bot.send_message(user_id, message).wait()
		bot_message_id = result.message_id
		print(bot_message_id)
		
		last_update_id = 0
		while(last_update_id < bot_message_id):
			updates = bot.get_updates().wait()
			last_update_id = updates[-1].message.message_id
			print(last_update_id)

		answer = str(updates[-1].message.text)
		information.append(answer)

	print(information)

	for i in range(len(information)):
		information[i] = float(information[i])

	with open("botInfo.txt", 'w') as csvfile:
		writer = csv.writer(csvfile)
		for i in range(len(information)):
			writer.writerow(information[i])

main()